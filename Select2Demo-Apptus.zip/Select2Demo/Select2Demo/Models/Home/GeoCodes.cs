﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Select2Demo.Models.Home
{
    public class GeoCodes
    {
        public string GeoNameId { get; set; }
        public string Name { get; set; }
        public string AsciiName { get; set; }
        public string AlternateNames { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string FeatureClass { get; set; }
        public string FeatureCode { get; set; }
        public string CountryCode { get; set; }
        public string Cc2 { get; set; }
        public string Admin1Code { get; set; }
        public string Admin2Code { get; set; }
        public string Admin3Code { get; set; }
        public string Admin4Code { get; set; }
        public long Population { get; set; }
        public string Elevation { get; set; }
        public int Dem { get; set; }
        public string GeoTimeZone { get; set; }
        public string ModificationDate { get; set; }
    }
}