﻿using Newtonsoft.Json;
using Select2Demo.Models.Home;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;

namespace Select2Demo.Data
{
    public class GeoCodesFileRepository : IGeoCodesRepository
    {
        public IQueryable<GeoCodes> _geoCodeList { get; set; }
        string _cacheKey = "geocodes";

        public GeoCodesFileRepository()
        {
            _geoCodeList = GenerateGeoCodes();
        }

        public GeoCodes GetGeoCodeDetails(string geoCode)
        {
            var geoCodeDetails = new GeoCodes();
            if (HttpContext.Current.Cache[_cacheKey] != null)
            {
                geoCodeDetails = ((IQueryable<GeoCodes>)HttpContext.Current.Cache[_cacheKey]).Where(a => string.Compare(a.GeoNameId, geoCode, StringComparison.InvariantCultureIgnoreCase) == 0).FirstOrDefault();
                return geoCodeDetails;
            }
            geoCodeDetails.GeoNameId = $"geo codes file not found in {AppDomain.CurrentDomain.BaseDirectory}";
            return geoCodeDetails;
        }
        public IQueryable<GeoCodes> GenerateGeoCodes()
        {
            //Check cache first before regenerating test data
            if (HttpContext.Current.Cache[_cacheKey] != null)
            {
                return (IQueryable<GeoCodes>)HttpContext.Current.Cache[_cacheKey];
            }
            var root = AppDomain.CurrentDomain.BaseDirectory;

            var fileName = $@"{root}{ConfigurationManager.AppSettings["FileName"]}";
            if (!File.Exists(fileName))
            {
                Trace.WriteLine($"{fileName} not exits in the path {root}");
                return null;
            }
            var details =
                from line in File.ReadLines(fileName)
                let tokens = line.Split('\t')
                select new GeoCodes
                {
                    GeoNameId = tokens[0],
                    Name = tokens[1],
                    AsciiName = tokens[2],
                    AlternateNames = tokens[3],
                    Latitude = double.Parse(tokens[4]),
                    Longitude = double.Parse(tokens[5]),
                    FeatureClass = tokens[6],
                    FeatureCode = tokens[7],
                    CountryCode = tokens[8],
                    Cc2 = tokens[9],
                    Admin1Code = tokens[10],
                    Admin2Code = tokens[11],
                    Admin3Code = tokens[12],
                    Admin4Code = tokens[13],
                    Population = long.Parse(tokens[14]),
                    Elevation = tokens[15],
                    Dem = int.Parse(tokens[16]),
                    GeoTimeZone = tokens[17],
                    ModificationDate = tokens[18]
                };

            var result = details.AsQueryable();

            //Cache results
            HttpContext.Current.Cache[_cacheKey] = result;

            return result;
        }
        public List<GeoCodes> GetGeocodes(string searchTerm, int pageSize, int pageNum)
        {
            var list = GeoCodesQuery(searchTerm)?
                .Skip(pageSize * (pageNum - 1))
                .Take(pageSize)
                .ToList();
            return list;
        }
        public int GetGeocodesCount(string searchTerm, int pageSize, int pageNum)
        {
            var query = GeoCodesQuery(searchTerm);
            if (query == null)
                return -1;
            return query.Count();
        }
        public IQueryable<GeoCodes> GeoCodesQuery(string searchTerm)
        {
            searchTerm = searchTerm.ToLower(CultureInfo.InvariantCulture);

            return _geoCodeList?
                .Where(
                    a =>
                    a.GeoNameId.StartsWith(searchTerm) || a.AsciiName.ToLower().Contains(searchTerm) || a.AlternateNames.ToLower().Contains(searchTerm)
                );
        }
    }
}