﻿using Select2Demo.Models.Home;
using System.Collections.Generic;
using System.Linq;

namespace Select2Demo.Data
{
    public interface IGeoCodesRepository
    {
        IQueryable<GeoCodes> GenerateGeoCodes();
        List<GeoCodes> GetGeocodes(string searchTerm, int pageSize, int pageNum);
        int GetGeocodesCount(string searchTerm, int pageSize, int pageNum);
        IQueryable<GeoCodes> GeoCodesQuery(string searchTerm);
        GeoCodes GetGeoCodeDetails(string geoCode);
    }
}