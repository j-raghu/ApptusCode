﻿using Select2Demo.Data;
using Select2Demo.Helpers;
using Select2Demo.Models.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Select2Demo.Controllers
{
    public class HomeController : Controller
    {
        IGeoCodesRepository _geoCodeRepos;
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Redirect to the confirmation page with the selected geo id
        /// </summary>
        [HttpPost]
        public ActionResult Index(IndexVm vm)
        {
            if (_geoCodeRepos == null)
                _geoCodeRepos = new GeoCodesFileRepository();

            var geoDetails = _geoCodeRepos.GetGeoCodeDetails(vm.GeoId);
            return PartialView("~/Views/Home/_GeoCodeDetails.cshtml", geoDetails);
            //return RedirectToAction("Confirmation", new { @id = vm.GeoId });
        }

        [HttpGet]
        public ActionResult GetGeocodes(string searchTerm, int pageSize, int pageNum)
        {
            //Get the paged results and the total count of the results for this query. 
            if (_geoCodeRepos == null)
                _geoCodeRepos = new GeoCodesFileRepository();

            List<GeoCodes> geoCodes = _geoCodeRepos.GetGeocodes(searchTerm, pageSize, pageNum);
            int geoCodeCount = _geoCodeRepos.GetGeocodesCount(searchTerm, pageSize, pageNum);
            //Translate the geoCodes into a format the select2 dropdown expects
            Select2PagedResult pagedGeoCodes = GeoCodesToSelect2Format(geoCodes, geoCodeCount);

            //Return the data as a jsonp result
            return new JsonpResult
            {
                Data = pagedGeoCodes,
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }
        private Select2PagedResult GeoCodesToSelect2Format(List<GeoCodes> geoCodes, int totalGeoCodes)
        {
            Select2PagedResult jsonGeoCodes = new Select2PagedResult();
            jsonGeoCodes.Results = new List<Select2Result>();
            if (geoCodes == null)
            {
                jsonGeoCodes.Results.Add(new Select2Result { id = "0", text = $"File not found in {AppDomain.CurrentDomain.BaseDirectory}" });
                jsonGeoCodes.Total = 1;
                return jsonGeoCodes;
            }
            //Loop through our Geo Codes and translate it into a text value and an id for the select list
            foreach (GeoCodes a in geoCodes)
            {
                jsonGeoCodes.Results.Add(new Select2Result { id = a.GeoNameId, text = $"{a.GeoNameId}-{a.AsciiName}" });
            }
            //Set the total count of the results from the query.
            jsonGeoCodes.Total = totalGeoCodes;

            return jsonGeoCodes;
        }
    }



    //Extra classes to format the results the way the select2 dropdown wants them
    public class Select2PagedResult
    {
        public int Total { get; set; }
        public List<Select2Result> Results { get; set; }
    }

    public class Select2Result
    {
        public string id { get; set; }
        public string text { get; set; }
    }
}
